from Main_App import user_inputs as u
from Main_App import fetch_records as f
from Main_App import fetch_on_branch as b
from Main_App import update_name as n
while True:
    print('''
    1.Enter participant details
    2.Fetch the participant records
    3.Fetch the participants based on branch
    4.update-name
    5.exit from app
    ''')
    print("choose any option from above menu")
    ch=int(input())
    if ch==1:
        u.input_data()
    elif ch==2:
        f.get_records()
        print("data fetched successfully")
    elif ch == 3:
        input_branch=input("enter a branch in caps:")
        b.get_on_branch(input_branch)
        print("--------")
    elif ch == 4:
        gid=int(input('enter gid to change name'))
        input_name=input("enter name to be replaced")
        n.update_name(gid,input_name)

    else:
        break