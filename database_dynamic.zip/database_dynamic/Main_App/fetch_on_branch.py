import sqlite3
"bootcampdb2.db"
conn=sqlite3.connect("bootcampdb2.db")
def get_on_branch(input_branch):
    records = conn.execute("select * from participants where branch='"+input_branch+"'")
    for i in records:
        print(i)

