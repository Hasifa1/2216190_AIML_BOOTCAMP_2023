import sqlite3

conn = sqlite3.connect("bootcampdb2.db")


def get_records():
    records = conn.execute('select * from participants')
    print(records)
    for i in records:
        print(i)
