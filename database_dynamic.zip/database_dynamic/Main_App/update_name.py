import sqlite3
"bootcampdb2.db"
conn=sqlite3.connect("bootcampdb2.db")
def update_name(gid,input_name):
    conn.execute("update participants set name='"+input_name+"' where g_id='"+str(gid)+"'")
    conn.commit()
    print("update success")