import sqlite3
"bootcampdb2.db"
conn=sqlite3.connect("bootcampdb2.db")
query='''
create table participants(G_id int primary key,name text not null,branch text not null,study text not null DEFAULT 'btech')
'''
conn.execute(query)
