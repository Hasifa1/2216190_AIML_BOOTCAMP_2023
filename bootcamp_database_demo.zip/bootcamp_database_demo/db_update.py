import sqlite3
"bootcamp23.db"
conn=sqlite3.connect("bootcamp23.db")
print(conn)
conn.execute("update participants set name='vyshnavi' where G_id=2216155")
conn.commit()
conn.close()
