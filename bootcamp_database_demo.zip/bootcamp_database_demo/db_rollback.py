import sqlite3
# 2,3.create db and establish connection
"bootcamp23.db"
conn = sqlite3.connect("bootcamp23.db")
print(conn)
conn.execute("delete from participants where G_id=2216190")
conn.execute("rollback")
print(conn.total_changes)
conn.commit()
conn.close()