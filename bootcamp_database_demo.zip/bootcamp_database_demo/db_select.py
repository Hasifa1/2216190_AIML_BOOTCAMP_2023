import sqlite3
"bootcamp23.db"
conn=sqlite3.connect("bootcamp23.db")
print(conn)

records=conn.execute("select * from participants")
print(records)
for i in records:
    print(i)
conn.commit()
conn.close()