import sqlite3
"bootcamp23.db"
conn=sqlite3.connect("bootcamp23.db")
print(conn)

'''
delete  record
'''
conn.execute("delete from participants where name='areefa'")
print(conn.total_changes)
#conn.execute("delete from participants")
#conn.execute("truncate table participants")
conn.commit()
conn.close()