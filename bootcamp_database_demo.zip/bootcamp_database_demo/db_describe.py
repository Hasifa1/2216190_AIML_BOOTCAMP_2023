import sqlite3
# 2,3.create db and establish connection
"bootcamp23.db"
conn = sqlite3.connect("bootcamp23.db")

records=conn.execute("pragma table_info(participants)")
print(records)
for i in records:
    print(i)
conn.commit()
conn.close()