import sqlite3
"bootcamp23.db"
conn=sqlite3.connect("bootcamp23.db")
print(conn)
'''
drop table table name ---deletes the entire table
'''
conn.execute("drop table participants")
conn.commit()
conn.close()