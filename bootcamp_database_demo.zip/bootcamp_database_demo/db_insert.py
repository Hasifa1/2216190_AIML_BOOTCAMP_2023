import sqlite3
# 2,3.create db and establish connection
"bootcamp23.db"
conn = sqlite3.connect("bootcamp23.db")
conn.execute("insert into participants values(2216190,'hasifa','cse','btech','hasifa@gmail.com')")
conn.execute("insert into participants values(2216192,'areefa','cse','btech','arifa@gmail.com')")
conn.execute("insert into participants values(2216155,'vyshu','ece','btech','vysh@gmail.com')")
conn.execute("insert into participants values(2216157,'rakshu','ece','btech','raksh@gmail.com')")
print(conn.total_changes)
conn.commit()
conn.close()