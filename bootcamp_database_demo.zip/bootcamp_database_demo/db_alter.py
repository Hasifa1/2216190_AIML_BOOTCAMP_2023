import sqlite3
"bootcamp23.db"
conn=sqlite3.connect("bootcamp23.db")
print(conn)

conn.execute('alter table participants add column mail_id text not null')
conn.commit()
conn.close()