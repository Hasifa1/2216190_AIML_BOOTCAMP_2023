# importing the module
# create a database
# establish a connection with database
# creating a table in db-participants table
# write a query and execute query


# 1.import
import sqlite3
# 2,3.create db and establish connection
"bootcamp23.db"
conn = sqlite3.connect("bootcamp23.db")


# create table table_name(column_name, datatype constraint(primary key,not null,unique,..))
query = '''create table participants(G_id int primary key,name text not null,branch text not null,study text not 
null)'''
conn.execute(query)
